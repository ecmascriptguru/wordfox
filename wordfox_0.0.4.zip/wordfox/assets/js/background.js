'use strict';

let Background = (function() {
    let _wordFox = null,// WordFoxPro,
        _data = [];

    let init = function() {
        // _wordFox.init();
    };

    return {
        init: init
    };
})();

(function(window, jQuery) {
    Background.init();
})(window, $);